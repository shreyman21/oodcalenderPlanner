package controller;

public class textualController {
 // for later
}
