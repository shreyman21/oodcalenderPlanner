package controller;

public interface plannerController {
  // for later
}
