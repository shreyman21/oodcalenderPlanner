package controller;

/**
 * This class represents the controller for the planner system.
 */
public class TextualController {
 // for later
}
