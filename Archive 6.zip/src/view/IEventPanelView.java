package view;

public interface IEventPanelView {
}
