package view;

public interface IMainSystemView {
}
