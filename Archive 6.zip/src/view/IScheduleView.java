package view;

public interface IScheduleView {

}
