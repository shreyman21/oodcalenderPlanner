package view;

public class IEventView {
}
