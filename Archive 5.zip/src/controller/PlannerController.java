package controller;

/**
 * This class represents the controller for the planner system.
 */
public interface PlannerController {
  // for later
}
