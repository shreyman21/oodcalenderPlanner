package view;

/**
 * This interface represents the view for the schedule.
 */
public interface IScheduleView {

}
