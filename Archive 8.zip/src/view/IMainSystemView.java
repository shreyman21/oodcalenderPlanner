package view;

/**
 * This interface represents the view for the main system.
 */
public interface IMainSystemView {
}
