package view;

/**
 * This class represents the GUI for the planner system.
 */
public class PlannerGui {
  // for later
}
